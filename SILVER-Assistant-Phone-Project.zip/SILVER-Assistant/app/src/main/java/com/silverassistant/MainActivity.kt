package com.silverassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var speech: SpeechRecognizer? = null
    private var torchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(PhoneBridge(), "SilverPhone")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class PhoneBridge {
        @JavascriptInterface fun deviceInfo(): String {
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return JSONObject().put("model", Build.MODEL)
                .put("android", Build.VERSION.RELEASE).put("battery", battery).toString()
        }

        @JavascriptInterface fun startListening() {
            runOnUiThread {
                if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) {
                    sendResult("Speech recognition is unavailable on this device.")
                    return@runOnUiThread
                }
                if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@MainActivity,
                        arrayOf(Manifest.permission.RECORD_AUDIO), 41)
                    sendResult("Allow microphone access, then tap the microphone again.")
                    return@runOnUiThread
                }
                speech?.destroy()
                speech = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
                speech?.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(results: Bundle?) {
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        sendResult(text ?: "I didn't catch that.")
                    }
                    override fun onError(error: Int) { sendResult("Voice recognition error. Please try again.") }
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to SILVER")
                }
                speech?.startListening(intent)
            }
        }

        @JavascriptInterface fun toggleFlashlight(): String {
            return try {
                val manager = getSystemService(CAMERA_SERVICE) as CameraManager
                val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    ?: return "This phone has no available flashlight."
                torchOn = !torchOn
                manager.setTorchMode(id, torchOn)
                if (torchOn) "Flashlight turned on." else "Flashlight turned off."
            } catch (e: Exception) { "Flashlight could not be changed. Check permissions or camera use." }
        }

        @JavascriptInterface fun setVolume(percent: Int): String {
            return try {
                val audio = getSystemService(AUDIO_SERVICE) as AudioManager
                val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val value = (percent.coerceIn(0, 100) * max / 100f).toInt()
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0)
                "Media volume set to ${percent.coerceIn(0, 100)} percent."
            } catch (e: Exception) { "Volume control is unavailable." }
        }

        @JavascriptInterface fun openSettings(page: String): String {
            val action = when (page.lowercase()) {
                "wifi", "internet" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            return try {
                startActivity(Intent(action)); "Opening $page settings."
            } catch (e: Exception) { "Could not open those settings." }
        }

        @JavascriptInterface fun openApp(packageName: String): String {
            val allowed = setOf(
                "com.android.settings", "com.android.chrome",
                "com.google.android.youtube", "com.whatsapp",
                "com.spotify.music", "com.google.android.apps.maps"
            )
            if (packageName !in allowed) return "That app isn't in SILVER's safe launch list."
            return try {
                val intent = packageManager.getLaunchIntentForPackage(packageName)
                    ?: return "App not found."
                startActivity(intent); "Opening app."
            } catch (e: Exception) { "Couldn't open that app." }
        }

        @JavascriptInterface fun speak(text: String) {
            runOnUiThread {
                val tts = android.speech.tts.TextToSpeech(this@MainActivity) { status ->
                    if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                        ttsEngine?.speak(text.take(500), android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "silver")
                    }
                }
                ttsEngine = tts
            }
        }

        private fun sendResult(text: String) {
            runOnUiThread {
                web.evaluateJavascript("window.onSilverSpeech(${JSONObject.quote(text)})", null)
            }
        }
    }

    private var ttsEngine: android.speech.tts.TextToSpeech? = null

    override fun onDestroy() {
        speech?.destroy()
        ttsEngine?.shutdown()
        web.destroy()
        super.onDestroy()
    }
}
