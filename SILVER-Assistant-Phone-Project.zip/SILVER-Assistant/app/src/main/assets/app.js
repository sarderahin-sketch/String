const $=id=>document.getElementById(id);
function log(who,msg){const p=document.createElement('p');const b=document.createElement('b');b.textContent=who+': ';p.append(b,document.createTextNode(msg));$('log').append(p);$('log').scrollTop=$('log').scrollHeight;}
function say(msg){log('SILVER',msg);try{SilverPhone.speak(msg)}catch(e){}}
function refreshInfo(){try{const d=JSON.parse(SilverPhone.deviceInfo());$('device').textContent=d.model;$('android').textContent=d.android;$('battery').textContent=d.battery+'%'}catch(e){$('device').textContent='Preview mode'}}
function listen(){$('status').textContent='LISTENING…';$('mic').textContent='LISTENING…';try{SilverPhone.startListening()}catch(e){$('status').textContent='VOICE BRIDGE UNAVAILABLE';$('mic').textContent='🎙 TALK TO SILVER'}}
window.onSilverSpeech=text=>{$('status').textContent='COMMAND RECEIVED';$('mic').textContent='🎙 TALK TO SILVER';log('YOU',text);handle(text)};
function runNative(action){let result='';try{if(action==='flash')result=SilverPhone.toggleFlashlight();else result=SilverPhone.openSettings(action)}catch(e){result='Native controls are available after installing the Android app.'}say(result)}
function handle(raw){const t=raw.toLowerCase();
if(t.includes('flashlight')||t.includes('torch')){runNative('flash');return}
if(t.includes('wifi')||t.includes('wi-fi')){runNative('wifi');return}
if(t.includes('bluetooth')){runNative('bluetooth');return}
if(t.includes('display')||t.includes('brightness')){runNative('display');return}
if(t.includes('sound')||t.includes('volume')){runNative('sound');return}
if(t.includes('battery')){runNative('battery');return}
if(t.includes('time')){say('The time is '+new Date().toLocaleTimeString());return}
if(t.includes('hello')||t.includes('hi silver')){say('Hello. SILVER is online and ready.');return}
if(t.includes('help')){say('I can control the flashlight and open Wi-Fi, Bluetooth, display, sound and battery settings.');return}
say('I can handle that with online AI once you connect a private AI service. For now, try “help” to hear my offline commands.');
}
function sendText(e){e.preventDefault();const v=$('command').value.trim();if(!v)return;$('command').value='';log('YOU',v);handle(v)}
refreshInfo();
