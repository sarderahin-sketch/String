# SILVER assistant — Android starter

A phone-first, no-root Android assistant for Samsung Galaxy A17. The app uses a native Kotlin Android shell and a JavaScript/HTML/CSS interface.

## Included now
- Tap-to-talk speech recognition using Android SpeechRecognizer.
- Spoken responses using Android TextToSpeech.
- Offline command routing for flashlight and opening Wi-Fi, Bluetooth, display, sound and battery settings.
- Device model, Android version and battery percentage.
- Crimson/black dashboard.

## Important limits
- This is a starter build, not unrestricted JARVIS. Android deliberately prevents ordinary apps from taking over the whole phone.
- Voice recognition may use Google's/on-device speech service and may need internet depending on the phone's installed language pack.
- The microphone is activated only after the user taps the microphone. No hidden always-listening service.
- “Open settings” opens Android's own settings page; SILVER does not silently change protected settings.
- The online AI mode is not connected yet. Add a trusted HTTPS backend that holds your AI provider key. Never put a private API key in app.js or an APK. The UI's offline command mode works without that backend.
- The app does not read messages, passwords, calls, or private app data.

## Build using only an Android phone
1. Install a reputable Android IDE that supports Gradle Kotlin projects, or use a mobile browser to create a private GitHub repository.
2. Upload this entire project folder to the repository.
3. GitHub Actions can build the APK in the cloud. Create `.github/workflows/android.yml` as described below, commit it, then open the Actions tab in your phone browser.
4. Download the generated APK from the successful workflow artifact.
5. On the phone, open the APK and approve “Install unknown apps” for the browser/files app when Android asks. Install SILVER.
6. Open SILVER, tap TALK TO SILVER, and grant microphone permission when prompted.

## GitHub Actions build workflow
Create `.github/workflows/android.yml` with:

```yaml
name: Build SILVER APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]
permissions:
  contents: read
  actions: read
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
      - uses: android-actions/setup-android@v3
      - name: Install Android SDK
        run: yes | sdkmanager --licenses && sdkmanager "platforms;android-36" "build-tools;36.0.0"
      - name: Build debug APK
        run: gradle :app:assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: SILVER-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

## Project structure
- `app/src/main/java/com/silverassistant/MainActivity.kt` — native Android bridge, speech, TTS, safe controls.
- `app/src/main/assets/index.html` — interface.
- `app/src/main/assets/style.css` — visual theme.
- `app/src/main/assets/app.js` — offline command handling.
- `app/src/main/AndroidManifest.xml` — app and microphone declarations.

## Android version
The project uses compile SDK 36 and target SDK 35 for a currently available Android toolchain. This is intended to run on Android 17 devices with backward compatibility, but the exact SDK installed on the phone must be verified by the build environment.
